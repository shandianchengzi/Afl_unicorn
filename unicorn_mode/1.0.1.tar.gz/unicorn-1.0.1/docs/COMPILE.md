To compile Unicorn on Mac OS X, Linux, BSD, Solaris and all kind of nix OS,
see [COMPILE-NIX.md](COMPILE-NIX.md)

To compile Unicorn on Windows, see [COMPILE-WINDOWS.md](COMPILE-WINDOWS.md)

Then learn more on how to code your own tools with our samples.

 - For C sample code, see code in directory samples/sample*.c
 - For Python sample code, see code in directory bindings/python/sample*.py
 - For samples of other bindings, look into directories bindings/<language>/
